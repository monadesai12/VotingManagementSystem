import axios from "axios";
import React from "react";
import PrimarySearchAppBar from "../components/PrimarySearchAppBar";
class NominateCandidate extends React.Component{
  constructor(props){
    super(props);
    this.state={
      partyName :"",
      symbol:"",
      election:[],
      electionId:"",
      user:[],
        id:"",
     
        currentUser:JSON.parse(localStorage.getItem("user")),
     
    };

    
    this.handleChange=this.handleChange.bind(this);
    this.handleSubmit=this.handleSubmit.bind(this);
  }

 

  componentDidMount(){
    console.log("Data Aa raha hai")
    axios.get( `http://localhost:8080/election/listAllElection`)
    .then((ResponseData)=> {console.log(ResponseData);
      this.setState({users:ResponseData.data})})
      .catch((error)=>{console.log("Error in Election Data")})
  }
  
  handleChange(event)
{   
    this.setState({
        ...this.state,
        [event.target.name] : event.target.value, 
    })

    console.log(this.state.partyName);
    console.log(this.state.symbol);
   
}

  handleSubmit = async (event) =>{
    event.preventDefault();
    let candidates ={
      partyName:this.state.partyName,
      symbol:this.state.symbol,
      election:{
      electionId:this.props.match.params.id
      },
      user:{
        id:this.state.currentUser.id
      },
     
    };

  await axios 
  .post(`http://localhost:8080/candidate/nominate`, candidates)
  .then((data) =>{alert("Nominates Successfully!")})
  .catch((error) => { alert(error.response.data);
  });
};



    render(){
    return(
    <div className= "container-sm mt-4 pd-4">

           
      <div className="card">
        <div className="card-body">
          
        <form>

        <div className="form-group">
          <label for="party">Party Name</label>
          <input type="text" name="partyName" className="form-control" id="party" value={this.state.partyName} onChange={this.handleChange} ></input>
        </div>

        <div className="form-group">
          <label for="sym">Symbol</label>
          <input type="text" name="symbol" className="form-control" id="sym" value={this.state.symbol} onChange={this.handleChange} ></input>
        </div>
       
        <button type="submit"  className="btn btn-primary" onClick={this.handleSubmit}>Submit</button>
      </form>
        </div>
      </div>
      
      </div>
    );
  }
}
export default NominateCandidate;


