import React from 'react';
import axios from 'axios';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { withStyles } from '@material-ui/core/styles';
import { TextareaAutosize } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';


const useStyles = (theme) => ({
    paper: {
      marginTop: theme.spacing(8),
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    },
    avatar: {
      margin: theme.spacing(1),
      backgroundColor: theme.palette.secondary.main,
    },
    form: {
      width: '100%', // Fix IE 11 issue.
      marginTop: theme.spacing(3),
    },
    submit: {
      margin: theme.spacing(3, 0, 2),
    },
     acc:{
       marginTop : theme.spacing(10),
     }
  });


class Register extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            firstName:'',
            lastName:'',
            age:'',
            mobileNumber:'',
            adharCardNumber:'',
            address:'',
            pincode:'',
            email:'',
            username:'',
            password:'',
            confirmPassword:'',
            gender:'',
            currentUser:JSON.parse(localStorage.getItem("user")),

        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    componentDidMount()
    {
          console.log("Update User Profile");
          axios.get(`http://localhost:8080/viewvoterByid/${this.state.currentUser.id}`)
          .then((responseUserData)=>{console.log(responseUserData);
              let user=responseUserData.data
          this.setState({
              firstName:user.firstName,
              lastName:user.lastName,
              age:user.age,
              mobileNumber:user.mobileNumber,
              adharCardNumber:user.adharCardNumber,
              address:user.address,
              pincode:user.pincode,
              email:user.email,
              username:user.username,
              gender:user.gender,
              password:user.password
                // users:responseUserData.data,
          }) })
          .catch((error)=>{console.log("Some error in user(voter) read data ");
        })
        console.log(this.state.currentUser.id)
        console.log(this.state.firstName)
        console.log(this.state.pincode)
  
        
    }

   

    handleChange(event)
    {  
        event.preventDefault();
        this.setState({
            ...this.state,
            [event.target.name] : event.target.value
        })
        console.log(this.state.firstName);
        console.log(this.state.lastName);

    }

    handleSubmit(event)
    {   
       event.preventDefault();

        axios.put(`http://localhost:8080/updateUser/${this.state.currentUser.id}`, {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            //age: this.state.age,
            mobileNumber: this.state.mobileNumber,
            //adharCardNumber: this.state.adharCardNumber,
            address : this.state.address,
            pincode: this.state.pincode,
            email: this.state.email,
           // username: this.state.username,
           // password: this.state.password,
           // gender: this.state.gender

          },)
          .then((ResponseData)=> {
              alert(ResponseData.data)
              console.log(ResponseData);
             
            })
            .catch((error)=>{
                
                console.log(error)})
            }
         
    
    render()
    {   
      const { classes } = this.props;
        return(
            <Container component="main" maxWidth="md">
            <CssBaseline />
            <div className={classes.paper}>
              <Typography component="h1" variant="h5">
                 Profile
              </Typography>
              <form className={classes.form} noValidate onSubmit={this.handleSubmit}>
                <Grid container spacing={2}>
                  <Grid item xs={12} sm={3}>
                    <TextField
                      autoComplete="fname"
                   
                      variant="outlined"
                      required
                      fullWidth
                      id="firstName"
                      label="First Name"
                      name="firstName"
                      value={this.state.firstName}
                      onChange={this.handleChange}
                      autoFocus
                    />
                  </Grid>
                  <Grid item xs={12} sm={3}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="lastName"
                      label="Last Name"
                      name="lastName"
                      value ={this.state.lastName}
                      onChange={this.handleChange}
                      autoComplete="lname"
                    />
                  </Grid>
                  <Grid item xs={12} sm={2}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="age"
                      label="Age"
                      type="number"
                      name="age"
                      disabled
                      value={this.state.age}
                      onChange={this.handleChange}
                      autoComplete="age"
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="Phone"
                      type="tel"
                      label="Phone"
                      name="mobileNumber"
                      value={this.state.mobileNumber}
                      onChange={this.handleChange}
                      autoComplete="Phone"
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      type="number"
                      id="AdharCardNumber"
                      label="AdharCard Number"
                      name="adharCardNumber"
                      disabled
                      value={this.state.adharCardNumber}
                      onChange={this.handleChange}
                      autoComplete="AdharCardNumber"
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="email"
                      type="email"
                      label="Email Address"
                      name="email"
                      value={this.state.email}
                      onChange={this.handleChange}
                      autoComplete="email"
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="username"
                      label="Username"
                      name="username"
                      value={this.state.username}
                      onChange={this.handleChange}
                      disabled
                      autoComplete="username"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="Address"
                      label="Address"
                      name="address"
                      value={this.state.address}
                      onChange={this.handleChange}
                      autoComplete="Address"
                    />
                  </Grid>
                  <Grid item xs={12} sm={4}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      type="string"
                      id="pincode"
                      label="PinCode"
                      name="pincode"
                      value={this.state.pincode}
                      onChange={this.handleChange}
                      autoComplete="pincode"
                    />
                  </Grid>
                  <Grid item xs={12} sm={2}>
                 
                  <FormControl variant="outlined"required className="w-100">
                 
                    <InputLabel>Select Gender</InputLabel>
                    <Select
                      native
                      label="Age"
                      value={this.state.gender} onChange={this.handleChange}
                      disabled
                    >
                      <option aria-label="None" value="" />
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="OTher">Other</option>
                    </Select>
                  </FormControl>
             
                  </Grid>
                </Grid>
                <Grid container spacing={4}>
                <Grid item xs={12} sm={4}>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  className={classes.submit}
                >
                  Update
                </Button>
                </Grid>
                
                  <Grid item xs={12} sm={4}>
                  
                  </Grid>
              </Grid>
               
              </form>
            </div>

          </Container>
           
                                         
 
        )
        }
    
}
export default withStyles(useStyles, { withTheme: true })(Register);
