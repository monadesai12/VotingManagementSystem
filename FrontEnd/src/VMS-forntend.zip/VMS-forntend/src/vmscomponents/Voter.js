import React, { Component }  from "react";
import axios from "axios";
import {NavLink} from "react-router-dom";




class Voter extends Component{
    constructor(props)
    {
        super(props);
        this.state={users:[],errmsg:""};
        this.deleteUser=this.deleteUser.bind(this);
       
        
    }
//==========================GET ALL Voters==============================================================================================================
  componentDidMount()
  {
        console.log(" Add voter componentDidMount excecuted");
        axios.get(`http://localhost:8080/listAllVoters`)
        .then((responseUserData)=>{console.log(responseUserData);
        this.setState({users:responseUserData.data,}) })
        .catch((error)=>{console.log("Some error in user(voter) read data ");
      })
  }
 //============================================================================================
 
 deleteUser=(id)=>{

    const User_API_BASE_URL = 'http://localhost:8080/deletevoter'
     axios.put(User_API_BASE_URL + '/' + id)
     .then( res => {
      this.setState({users: this.state.users.filter(users => users.id !== id)});
    });
    //this.props.history.replace("allusers")
   
}
//============================================================================================

//============================================================================================  
    render()
    {
        var AllVotersList=this.state.users.map(
            (Voters,index)=>
            {
            return (    
                <tr key={Voters.id}>
                      <td>{Voters.id}</td>
                      <td>{Voters.firstName}</td>
                      <td>{Voters.lastName}</td>
                      <td>{Voters.age}</td>
                      <td>{Voters.address}</td>
                      <td>{Voters.mobileNumber}</td>
                      <td>{Voters.adharCardNumber}</td>
                      <td><button  type="button" class="btn btn-danger mr-4"
                      onClick={ () => this.deleteUser(Voters.id)} >DELETE</button>
                     </td>              
                </tr>)
            }
        );
        return (
            <div className="py-8">
            <h2 align="center" > Voters List </h2>
            <table class="table table-striped table-white table-bordered" border="3">
            <tr>
                <th scope="col" className = "bg-dark text-white" >Voter Id</th>
                <th scope="col" className = "bg-dark text-white" >First Name</th>
                <th scope="col" className = "bg-dark text-white" >Last Name</th>
                <th scope="col" className = "bg-dark text-white" >Age</th>
                <th scope="col" className = "bg-dark text-white">Address</th> 
                <th scope="col" className = "bg-dark text-white">Mobile Number</th>  
                <th scope="col" className = "bg-dark text-white">AdharCard Number</th>  
                <th scope="col" className = "bg-dark text-white">Action</th>    
            </tr>  
                    {AllVotersList}
            </table>
        </div>
        );
    }
}

export default Voter;



/*

*/ 