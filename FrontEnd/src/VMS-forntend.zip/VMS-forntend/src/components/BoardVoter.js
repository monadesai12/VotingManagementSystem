import React from "react";

const BoardVoter = () => {
  return (
    <div className="container">
      <header className="jumbotron">
        <h3>Voter Board</h3>
      </header>
    </div>
  );
};

export default BoardVoter;