import React from 'react';
import axios from 'axios';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';


class Register extends React.Component
{
    constructor(props)
    {
        super(props);
        this.state={
            firstName:'',
            lastName:'',
            age:'',
            mobileNumber:'',
            adharCardNumber:'',
            address:'',
            pincode:'',
            email:'',
            username:'',
            password:'',
            confirmPassword:'',
            gender:''

        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    handleChange(event)
    {  
        event.preventDefault();
        this.setState({
            ...this.state,
            [event.target.name] : event.target.value
        })
        console.log(this.state.firstName);
        console.log(this.state.lastName);

    }

    handleSubmit(event)
    {   
       event.preventDefault();

       if(this.state.password === this.state.confirmPassword)
       {
        axios.post(`http://localhost:8080/register`, {
            firstName: this.state.firstName,
            lastName: this.state.lastName,
            age: this.state.age,
            mobileNumber: this.state.mobileNumber,
            adharCardNumber: this.state.adharCardNumber,
            address : this.state.address,
            pincode: this.state.pincode,
            email: this.state.email,
            username: this.state.username,
            password: this.state.password,
            gender: this.state.gender

          },)
          .then((ResponseData)=> {
              alert(ResponseData.data)
              console.log(ResponseData);
              this.props.history.replace("/login");
            })
            .catch((error)=>{
                 alert(error.response.data)
                console.log(error.response.data)})
            }
            else
            {
                alert("Password mismatch")
            }  
    }
    render()
    {
        return(
            <div className="container-sm">
            <div className="card">
                <div className="card-header">
                    Register
                </div>
                <div className="card-body">
                    <form onSubmit={this.handleSubmit}>
                        <div className="form-row">
                            <div className="form-group col-md-4 mb-3">
                                <label for="firstName">First Name</label>
                                <input type="text"
                                 id="firstName" 
                                 className="form-control"
                                 name="firstName"
                                 value={this.state.firstName}
                                 onChange={this.handleChange}
                                 />
                            </div>
                            <div className="form-group col-md-4 mb-3">
                                <label for="lastName">Last Name</label>
                                <input type="text" 
                                 id="lastName" 
                                 className="form-control"
                                 name="lastName"
                                 value ={this.state.lastName}
                                 onChange={this.handleChange}
                                 />
                            </div>
                            <div className="form-group col-md-4 mb-3">
                                <label for="age">Age</label>
                                <input type="number" 
                                 id="age" 
                                 className="form-control"
                                 name="age"
                                 value={this.state.age}
                                 onChange={this.handleChange}
                                 />
                            </div>
                            <div className="form-group col-md-4">
                                <label for="mobileNumber">Mobile Number</label>
                                <input type="tel" 
                                 id="mobileNumber" 
                                 className="form-control"
                                 name="mobileNumber"
                                 value={this.mobileNumber}
                                 onChange={this.handleChange}
                                 />
                            </div>
                            <div className="form-group col-md-6">
                                <label for="adharCardNumber">AdharCard Number</label>
                                <input type="tel" 
                                 id="adharCardNumber" 
                                 className="form-control"
                                 name="adharCardNumber"
                                 value={this.adharCardNumber}
                                 onChange={this.handleChange}
                                 />
                            </div>
                            <div className="form-group col-md-2">
                                <label for="pincode">Zip Code</label>
                                <input type="text" 
                                 id="pincode" 
                                 className="form-control"
                                 name="pincode"
                                 value={this.pincode}
                                 onChange={this.pincode}
                                 />
                            </div>
                            <div className="form-group col-md-12">
                                <label for="address">Address </label>
                                <textarea class="form-control" 
                                    rows="2"
                                    className="form-control" 
                                    id="address"
                                    name="address"
                                    value={this.address}
                                    onChange={this.handleChange}
                                    >
                                </textarea>
                            </div>
                            <div className="form-group col-md-12">
                            <select  name="gender"class="custom-select" value={this.gender} onChange={this.handleChange} >
                                <option selected>Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="OTher">Other</option>
                            </select>
                            </div>
                              <div className="form-group col-md-6">
                            <label for="email">Email</label>
                                <input type="email" 
                                 id="email" 
                                 className="form-control"
                                 name="email"
                                 value={this.email}
                                 onChange={this.handleChange}
                                 />
                            </div>
                             <div className="form-group col-md-6">
                                <label for="username">Username</label>
                                    <input type="text" 
                                    id="username" 
                                    className="form-control"
                                    name="username"
                                    value={this.username}
                                    onChange={this.handleChange}
                                    />
                            </div>
                          
                            <div className="form-group col-md-6">
                            <label for="password">Password</label>
                                <input type="password" 
                                 id="password" 
                                 className="form-control"
                                 name="password"
                                 value={this.password}
                                 onChange={this.handleChange}
                                 />
                            </div>

                            <div className="form-group col-md-6">
                            <label for="password">Password</label>
                                <input type="password" 
                                 id="confirmPassword" 
                                 className="form-control"
                                 name="confirmPassword"
                                 value={this.confirmPassword}
                                 onChange={this.handleChange}
                                 />
                            </div>
                           
                        </div>
                           
                       
                        <button type="submit" className="btn btn-primary">Sign in</button>
                    </form>
        
            </div>
            </div>
            </div>
 
        )
        }
    
}

export default Register;